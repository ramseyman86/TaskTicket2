import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
            <div className="footer">
                <p>Full-Stackers Co. Trademark &copy;  2019</p>
            </div>
        )
    }
}


export default Footer;